<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Activity - Abiyyuza <?php $__env->endSlot(); ?>

    <header class="mb-10 animate-enter" style="animation-delay: 0.1s;">
        <h1 class="text-3xl md:text-4xl font-extrabold text-white mb-3 tracking-tight">
            Coding Activity <span class="text-4xl"></span>
        </h1>
        <p class="text-gray-400 text-lg">
            Jejak digital dan kontribusi kode saya di dunia Open Source.
        </p>
    </header>

    <div class="animate-enter relative" style="animation-delay: 0.2s;">
        
        <div class="absolute -inset-1 bg-gradient-to-r from-green-600 to-emerald-600 rounded-3xl blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>

        <div class="relative bg-[#0a0a0a] border border-white/10 p-6 md:p-8 rounded-2xl shadow-2xl overflow-hidden group hover:border-green-500/30 transition duration-500">
            
            <div class="absolute top-0 right-0 w-64 h-64 bg-green-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>

            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4 relative z-10">
                <div>
                    <h2 class="text-xl font-bold text-white flex items-center gap-2">
                        <svg class="w-6 h-6 text-green-500" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
                        GitHub Contributions
                    </h2>
                    <p class="text-sm text-gray-500 font-mono mt-1">@mrafiabi123-crypto</p>
                </div>
                
                <a href="https://github.com/mrafiabi123-crypto" target="_blank" class="px-5 py-2.5 bg-white text-black font-bold text-sm rounded-xl hover:bg-gray-200 transition shadow-lg hover:shadow-green-500/20 flex items-center gap-2 transform active:scale-95">
                    Visit Profile
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                </a>
            </div>

            <div class="w-full overflow-x-auto pb-2 scrollbar-hide">
                <img src="https://ghchart.rshah.org/10b981/mrafiabi123-crypto" 
                     alt="Github Chart" 
                     class="min-w-[800px] w-full opacity-80 group-hover:opacity-100 transition duration-500 filter contrast-125">
            </div>

            <div class="mt-6 flex flex-wrap gap-4 text-xs text-gray-500 border-t border-white/5 pt-4">
                <div class="flex items-center gap-2">
                    <span class="w-3 h-3 bg-[#161b22] border border-white/10 rounded-sm"></span> No Activity
                </div>
                <div class="flex items-center gap-2">
                    <span class="w-3 h-3 bg-[#0e4429] rounded-sm"></span> Low
                </div>
                <div class="flex items-center gap-2">
                    <span class="w-3 h-3 bg-[#26a641] rounded-sm"></span> Medium
                </div>
                <div class="flex items-center gap-2">
                    <span class="w-3 h-3 bg-[#39d353] rounded-sm shadow-[0_0_10px_#39d353]"></span> High Activity
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8 animate-enter" style="animation-delay: 0.3s;">
        <div class="bg-[#111] p-6 rounded-2xl border border-white/5 hover:border-blue-500/30 transition group">
            <div class="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center mb-4 text-blue-500 group-hover:scale-110 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
            </div>
            <h3 class="text-white font-bold text-lg">Consistent</h3>
            <p class="text-gray-500 text-sm mt-1">Coding hampir setiap hari untuk meningkatkan skill.</p>
        </div>

        <div class="bg-[#111] p-6 rounded-2xl border border-white/5 hover:border-purple-500/30 transition group">
            <div class="w-10 h-10 bg-purple-500/10 rounded-lg flex items-center justify-center mb-4 text-purple-500 group-hover:scale-110 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path></svg>
            </div>
            <h3 class="text-white font-bold text-lg">Achiever</h3>
            <p class="text-gray-500 text-sm mt-1">Fokus menyelesaikan proyek hingga tahap deployment.</p>
        </div>

        <div class="bg-[#111] p-6 rounded-2xl border border-white/5 hover:border-pink-500/30 transition group">
            <div class="w-10 h-10 bg-pink-500/10 rounded-lg flex items-center justify-center mb-4 text-pink-500 group-hover:scale-110 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
            </div>
            <h3 class="text-white font-bold text-lg">Passionate</h3>
            <p class="text-gray-500 text-sm mt-1">Mencintai apa yang saya kerjakan & belajar hal baru.</p>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\mydashboard\resources\views/projects.blade.php ENDPATH**/ ?>