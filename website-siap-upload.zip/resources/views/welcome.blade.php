<x-layout>
    <x-slot:title>Dashboard - Abiyyuza</x-slot:title>

    <header class="mb-12 animate-enter" style="animation-delay: 0.1s;">
        <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight leading-tight">
            Creative Developer <br>
            <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                & UI/UX Enthusiast
            </span>
        </h1>
        <p class="text-gray-400 max-w-2xl text-lg leading-relaxed">
            I build accessible, pixel-perfect, secure, and performant web applications. 
            Currently focused on the Laravel & Tailwind ecosystem.
        </p>
    </header>
    <style>
        @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        .animate-marquee {
            display: flex;
            width: max-content;
            animation: marquee 30s linear infinite;
        }
        .group:hover .animate-marquee {
            animation-play-state: paused;
        }
    </style>

    <div class="relative w-full overflow-hidden mb-16 group">
        
        <div class="absolute z-10 top-0 left-0 h-full w-24 bg-gradient-to-r from-[#0a0a0a] to-transparent"></div>
        <div class="absolute z-10 top-0 right-0 h-full w-24 bg-gradient-to-l from-[#0a0a0a] to-transparent"></div>

        <div class="animate-marquee flex gap-12 items-center opacity-60 hover:opacity-100 transition duration-500">
            
            <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/laravel/FF2D20" alt="Laravel" class="w-8 h-8">
                <span class="font-bold text-xl text-gray-300">Laravel</span>
            </div>

            <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/tailwindcss/06B6D4" alt="Tailwind" class="w-8 h-8">
                <span class="font-bold text-xl text-gray-300">Tailwind</span>
            </div>

            <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/php/777BB4" alt="PHP" class="w-10 h-10">
                <span class="font-bold text-xl text-gray-300">PHP</span>
            </div>

            <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/javascript/F7DF1E" alt="JS" class="w-8 h-8 rounded-md">
                <span class="font-bold text-xl text-gray-300">JavaScript</span>
            </div>

             <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/mysql/4479A1" alt="MySQL" class="w-10 h-10">
                <span class="font-bold text-xl text-gray-300">MySQL</span>
            </div>

            <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/git/F05032" alt="Git" class="w-8 h-8">
                <span class="font-bold text-xl text-gray-300">Git</span>
            </div>


            <div class="flex items-center gap-3 pl-12">
                <img src="https://cdn.simpleicons.org/laravel/FF2D20" alt="Laravel" class="w-8 h-8">
                <span class="font-bold text-xl text-gray-300">Laravel</span>
            </div>
            <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/tailwindcss/06B6D4" alt="Tailwind" class="w-8 h-8">
                <span class="font-bold text-xl text-gray-300">Tailwind</span>
            </div>
            <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/php/777BB4" alt="PHP" class="w-10 h-10">
                <span class="font-bold text-xl text-gray-300">PHP</span>
            </div>
            <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/javascript/F7DF1E" alt="JS" class="w-8 h-8 rounded-md">
                <span class="font-bold text-xl text-gray-300">JavaScript</span>
            </div>
             <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/mysql/4479A1" alt="MySQL" class="w-10 h-10">
                <span class="font-bold text-xl text-gray-300">MySQL</span>
            </div>
             <div class="flex items-center gap-3">
                <img src="https://cdn.simpleicons.org/git/F05032" alt="Git" class="w-8 h-8">
                <span class="font-bold text-xl text-gray-300">Git</span>
            </div>

        </div>
    </div>
    

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div class="animate-enter bg-[#0a0a0a] border border-white/5 p-6 rounded-2xl hover:border-white/10 hover:bg-[#111] transition duration-300 group">
            <p class="text-sm font-medium text-blue-400 mb-1">Public Repositories</p>
            <h3 class="text-3xl font-bold text-white">{{ $github['public_repos'] ?? 0 }}</h3>
        </div>
        <div class="animate-enter bg-[#0a0a0a] border border-white/5 p-6 rounded-2xl hover:border-white/10 hover:bg-[#111] transition duration-300 group">
            <p class="text-sm font-medium text-purple-400 mb-1">Community</p>
            <h3 class="text-3xl font-bold text-white">{{ $github['followers'] ?? 0 }}</h3>
        </div>
        <div class="animate-enter bg-[#0a0a0a] border border-white/5 p-6 rounded-2xl hover:border-white/10 hover:bg-[#111] transition duration-300 group">
            <p class="text-sm font-medium text-green-400 mb-1">Experience</p>
            <h3 class="text-3xl font-bold text-white">2+</h3>
        </div>
        <div class="animate-enter bg-[#0a0a0a] border border-white/5 p-6 rounded-2xl hover:border-white/10 hover:bg-[#111] transition duration-300 group">
            <p class="text-sm font-medium text-pink-400 mb-1">Total Projects</p>
            <h3 class="text-3xl font-bold text-white">10+</h3>
        </div>
    </div>

    <section class="animate-enter" style="animation-delay: 0.6s;">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="w-2 h-2 bg-blue-500 rounded-full"></span>
                Latest Projects
            </h2>
            <a href="{{ route('projects') }}" class="text-xs text-gray-400 hover:text-white transition">View Activity -></a>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            @forelse($repos as $repo)
            <a href="{{ $repo['html_url'] }}" target="_blank" class="group bg-[#0a0a0a] border {{ isset($repo['manual']) ? 'border-blue-500/50 shadow-lg shadow-blue-500/10' : 'border-white/5' }} p-6 rounded-2xl hover:border-white/20 transition-all duration-300 hover:-translate-y-1 relative overflow-hidden">
                
                @if(isset($repo['manual']))
                <div class="absolute inset-0 bg-blue-500/5 pointer-events-none"></div>
                <div class="absolute top-0 right-0 p-2">
                     <span class="bg-blue-500 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-lg">FEATURED</span>
                </div>
                @endif

                <div class="flex justify-between items-start mb-4 relative z-10">
                    <div class="p-2 rounded-lg {{ isset($repo['manual']) ? 'bg-blue-500/20 text-blue-400' : 'bg-white/5 text-gray-400' }} border border-white/5">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path></svg>
                    </div>
                    <div class="flex items-center gap-1 text-xs font-mono text-gray-500 bg-black/50 px-2 py-1 rounded-full border border-white/5">
                        <svg class="w-3 h-3 text-yellow-500" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                        {{ $repo['stargazers_count'] }}
                    </div>
                </div>

                <h3 class="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition relative z-10">{{ $repo['name'] }}</h3>
                <p class="text-sm text-gray-400 line-clamp-2 relative z-10">
                    {{ $repo['description'] ?? 'No description provided for this repository.' }}
                </p>
            </a>
            @empty
            <div class="col-span-2 text-gray-500 text-center py-10 bg-[#0a0a0a] rounded-2xl border border-white/5">
                No repositories found.
            </div>
            @endforelse
        </div>
    </section>
</x-layout>